#include <stdio.h>
#include <stdlib.h>
#include <string.h>
// 231488347
// 231453415

int main(int argc, char *argv[]){
    FILE *fp;
    

    if(argc != 3){
	printf("This program needs a text file as argument\n");
	exit(0);
	}

	fp = fopen(argv[1],"r");
    char count_char = *argv[2];

	if (fp == NULL){
		printf("Error opening file");
		exit(0);
	}

    char* buff = (char*) malloc(sizeof(char)*1000);

    //buff = fgetc(fp);
    char store_c = ' ';
    int counter = 0;
    int len = 0;
    int line_num = 1; 
    int num_of_lines = 0;
    int num_of_c_in_line = 0;

    int num_of_c_in_line_arr [10];
    int i = 0;

    while(store_c != EOF){
        //buff[len] = line_num;
        //len++;
        
        store_c = fgetc(fp);
        num_of_c_in_line ++;
        if (store_c == count_char){
            counter ++;
        }
        if (store_c == '\n'){
            num_of_lines++;
            num_of_c_in_line_arr[i] = num_of_c_in_line-1;
            num_of_c_in_line = 0;
            i++;
        }
        buff[len] = store_c;
        len ++;

    }

    for (int i = 0, j = 1; i<len-1;i++){
        if(i ==0 || buff[i-1] == '\n'){
            printf("\n%d. ",j);
            j++;
        }
        if(buff[i] != '\n'){
            printf("%c",buff[i]);
        
        }

    }
   // printf(buff,stdout);
    
    printf("\nNumber of lines in file:%d\n",num_of_lines); 
    int e = 0;
    while (num_of_c_in_line_arr[e] != 0){
            printf("Number of charaters in line No.%d: %d\n",e+1,num_of_c_in_line_arr[e]);
            e++;

    }
    printf("Character '%c' found %d times in file.\n",count_char,counter );
    
    return 0;

}